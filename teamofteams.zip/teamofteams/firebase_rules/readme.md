To install all the packages:
npm install

To run the tests:
npm test