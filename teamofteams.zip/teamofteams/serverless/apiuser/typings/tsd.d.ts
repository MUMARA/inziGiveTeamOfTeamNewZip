
/// <reference path="mongoose/mongoose.d.ts" />
/// <reference path="node/node.d.ts" />
/// <reference path="aws-sdk/aws-sdk.d.ts" />
/// <reference path="aws-sdk/lambda.d.ts" />
/// <reference path="node-uuid/node-uuid-base.d.ts" />
/// <reference path="node-uuid/node-uuid-cjs.d.ts" />
/// <reference path="node-uuid/node-uuid.d.ts" />
/// <reference path="firebase/firebase.d.ts" />
/// <reference path="q/Q.d.ts" />
/// <reference path="firebase-token-generator/firebase-token-generator.d.ts" />
/// <reference path="ejs/ejs.d.ts" />